<?php
session_start();
if (isset($_GET['id'])) {
    // Retrieve the value of 'id'
    $id = $_GET['id'];
} if (isset($_GET['keg'])) {
    // Retrieve the value of 'id'
    $keg = $_GET['keg'];
}else {
    // Handle the case when 'id' is not provided
    echo "Data Kegiatan Pengujian Yang anda cari tidak ditemukan.";
    //exit;
}
// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // If logged in, display "Welcome Username" message
    echo "<center>Penguji Aktif : <b>" . $_SESSION['username'] . " </b><a href='logout.php'>Logout</a></center>";
} else {
    // If not logged in, display "Welcome" message with a "Login" link
    echo "Silahkan <a href='login.php'>Login</a>";
	header("Location: login.php");
    exit();
}
setlocale(LC_TIME, 'id_ID.utf8');
?>
<?php
// Replace these variables with your actual database credentials
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// First query to retrieve data from tabel_registrasi
$sql1 = "SELECT id_pemeriksaan, id_Registrasi, Tanggal_Pemeriksaan, Tempat_Pemeriksaan, Nama_Penguji_Pemeriksaan, Nomor_kendaraan, Nomor_Pemeriksaan, Nama_Pemilik, Jenis, Nomor_Rangka, Nomor_Mesin, Merk_Tipe_tahun, Landasan_Frame, As_Gardan_belakang, As_Gardan_depan, Pesawat_rem_peralatannya, Kemudi_peralatannya, Mesin, Cluth_Bak_Versneling, Alat_pengatur_bahan_baker, Pendingin, Ban_ban, Roda_dan_penutup_roda, Bodi_Badan, Spartdburd, Alat_Listrik, Alat_alat_pembakar, Dashboard, Lampu_lampu, Penahan_Shock_peer, Kaca_kaca, Grill_mask, Keadaan_cat, Atap_lantai_tempat_duduk, Perkakas, Alat_alat_lain, totalCount1,totalCount, average, teoriti, teknistetap, catatan
         FROM tabel_penilaian
         WHERE id_pemeriksaan = $id";

$result1 = $conn->query($sql1);

if (!$result1) {
    die("Query 1 failed: " . mysql_error());
}






// Second query to retrieve data from tabel_penilaian
$sql2 = "SELECT id_Registrasi, Tanggal_Pemeriksaan, Tempat_Pemeriksaan, Nomor_Surat_Pemeriksaan, Tanggal_Surat_Pemeriksaan, Nama_Penguji_Pemeriksaan, Nomor_agenda, Tanggal_Agenda, No_Surat_Permintaan, Tanggal_Surat_Permintaan, Dari_Permintaan
         FROM tabel_registrasi
         WHERE id_Registrasi = $keg";
$result2 = $conn->query($sql2);

if (!$result2) {
    die("Query 2 failed: " . mysql_error());
}




// Fetch and display the results from the first query
if ($result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
        $Tanggal_Surat_Pemeriksaan = $row["Tanggal_Surat_Pemeriksaan"];
		$timestamp1 = strtotime($Tanggal_Surat_Pemeriksaan);
        $Tanggal_Surat_Permintaan = $row["Tanggal_Surat_Permintaan"];
		$timestamp2 = strtotime($Tanggal_Surat_Permintaan);
		$Tanggal_Agenda = $row["Tanggal_Agenda"];
		$timestamp4 = strtotime($Tanggal_Agenda);
		
		$TanggalSuratPemeriksaan = strftime('%e %B %Y', $timestamp1);
		$TanggalSuratPermintaan = strftime('%e %B %Y', $timestamp2);
		$TanggalAgenda = strftime('%e %B %Y', $timestamp4);		
		$Tempat_Pemeriksaan = $row["Tempat_Pemeriksaan"];
		$Nomor_Surat_Pemeriksaan = $row["Nomor_Surat_Pemeriksaan"];
		$Nama_Penguji_Pemeriksaan = $row["Nama_Penguji_Pemeriksaan"];
		$Nomor_agenda = $row["Nomor_agenda"];
		$No_Surat_Permintaan = $row["No_Surat_Permintaan"];
		$Dari_Permintaan = $row["Dari_Permintaan"];

    }
} else {
    echo "No records found for the first query.";
}

echo "<br>"; // Add a line break for separation of results

// Fetch and display the results from the second query
if ($result1->num_rows > 0) {
    while ($row = $result1->fetch_assoc()) {
        $Tanggal_Pemeriksaan = $row["Tanggal_Pemeriksaan"];
		$timestamp3 = strtotime($Tanggal_Pemeriksaan);
		
		
		
		$TanggalPemeriksaan = strftime('%e %B %Y', $timestamp2);
		$id_pemeriksaan = $row["id_pemeriksaan"];
		$id_Registrasi = $row["id_Registrasi"];
		$Tempat_Pemeriksaan = $row["Tempat_Pemeriksaan"];
		$Nama_Penguji_Pemeriksaan = $row["Nama_Penguji_Pemeriksaan"];
		$Nomor_kendaraan = $row["Nomor_kendaraan"];
		$Nomor_Pemeriksaan = $row["Nomor_Pemeriksaan"];
		$Nama_Pemilik = $row["Nama_Pemilik"];
		$Jenis = $row["Jenis"];
		$Nomor_Rangka = $row["Nomor_Rangka"];
		$Nomor_Mesin = $row["Nomor_Mesin"];
		$Merk_Tipe_tahun = $row["Merk_Tipe_tahun"];
		$Landasan_Frame = $row["Landasan_Frame"];
		$As_Gardan_belakang = $row["As_Gardan_belakang"];
		$As_Gardan_depan = $row["As_Gardan_depan"];
		$Pesawat_rem_peralatannya = $row["Pesawat_rem_peralatannya"];
		$Kemudi_peralatannya = $row["Kemudi_peralatannya"];
		$Mesin = $row["Mesin"];
		$Cluth_Bak_Versneling = $row["Cluth_Bak_Versneling"];
		$Alat_pengatur_bahan_baker = $row["Alat_pengatur_bahan_baker"];
		$Pendingin = $row["Pendingin"];
		$Ban_ban = $row["Ban_ban"];
		$Roda_dan_penutup_roda = $row["Roda_dan_penutup_roda"];
		$Bodi_Badan = $row["Bodi_Badan"];
		$Spartdburd = $row["Spartdburd"];
		$Alat_Listrik = $row["Alat_Listrik"];
		$Alat_alat_pembakar = $row["Alat_alat_pembakar"];
		$Dashboard = $row["Dashboard"];
		$Lampu_lampu = $row["Lampu_lampu"];
		$Penahan_Shock_peer = $row["Penahan_Shock_peer"];
		$Kaca_kaca = $row["Kaca_kaca"];
		$Grill_mask = $row["Grill_mask"];
		$Keadaan_cat = $row["Keadaan_cat"];
		$Atap_lantai_tempat_duduk = $row["Atap_lantai_tempat_duduk"];
		$Perkakas = $row["Perkakas"];
		$Alat_alat_lain = $row["Alat_alat_lain"];
		$totalCount1 = $row["totalCount1"];
		$totalCount = $row["totalCount"];
		$average = $row["average"];
		$teoriti = $row["teoriti"];
		$teknistetap = $row["teknistetap"];
		$catatan = $row["catatan"];
    }
} else {
    echo "No records found for the second query.";
}

// Close the MySQL connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Pemeriksaan Teknis Kendaraan</title>
  <style>
    .aesthetic-div {
      width: 80%;
      height: auto;
      background-color: #F8F8F8;
      border: 1px solid #E6E6E6;
      border-radius: 10px;
      box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);
      font-family: Arial, sans-serif;
      
      color: #333333;
      text-align: left;
    }
	.container {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    body {
      margin: 12;
      padding: 12;
      font-family: Arial, sans-serif;
	        justify-content: center;
      align-items: center;
    }
    
    .landing {
      position: relative;
      height: auto;
	  opacity: 100;
      background-image: url('index_files/abstract-template-blue-background-white-squares-free-vector.jpg');
      background-size: cover;
      background-position: center;
    }
    
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 255, 0.7);
    }
    
    .content {
      position: relative;
      z-index: 1;
      text-align: center;
      color: #fff;
    }
    
    .section {
      opacity: 5;
      transform: translateY(50px);
      transition: opacity 0.5s ease, transform 0.5s ease;
    }
    
    .section.animated {
      opacity: 1;
      transform: translateY(0);
    }
	    h2 {
      background: linear-gradient(to right, #3F51B5, #2196F3);
      color: #FFFFFF;
      padding: 10px;
      border-radius: 5px;
      font-family: Arial, sans-serif;
      text-align: center;
    }
	    input[type="text"] {
      width: 80%;
	  height: 30px;
    }
	    table {
     
	   width: 100%;
    }
	    tr {
		font-size: 25px;
 
    }

  </style>
</head>
<body>
 <center> <div class="aesthetic-div">
  <div class="landing">
    <div class="overlay"></div>
    <div class="content">
      <h1>PEMERIKSAAN TEKNIS KENDARAAN</h1>
      <p>DISHUB MAGETAN</p>
	  <img src="logo.png"/><br/>
	    <a href="index.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Home</a>
		<a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Cetak</a>
		    <button style="display: inline-block; padding: 10px 20px; background-color: red; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" onclick="goBack()">Kembali</button>

    <script>
        function goBack() {
            // Navigate back to the previous page
            window.history.back();
        }
    </script>
    </div>
  </div>

  <div class="section"><form action="gen.php" method="post">
	     <h2>Pengujian Kendaraan Bermotor</h2>


<div class="cetak">
<style>.size {display: inline-block;width: 50%;}.colon {display: inline-block;width: 20px;text-align: center;}.my-div {width: 21cm;height: 27.5cm;background-color: white;border: 0px solid black;line-height: 1.15;}@media (min-width: 768px) {.my-div {width: 21cm;height: 33.2cm;}}.indented {margin-left: 1.5cm;margin-right: 1.5cm;}.indented2 {margin-left: 1cm;margin-right: 1.5cm;}.ttdkadin {margin-left: 10cm;margin-right: 1.5cm;}</style>	<div class='my-div'><center><img width='auto' height='auto' src='https://danangmardyanto.kir.my.id/header.png'/><br/><u><b>BERITA ACARA  PEMERIKSAAN TEKNIS KENDARAAN</b></u><br/>Nomor : <?php echo $Nomor_Surat_Pemeriksaan; ?></center>


<div class='indented2'>
I. Identitas Kendaraan<br/></div>
<div class='indented'>
<span class='size'>a. Nomor Kendaraan</span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_kendaraan;?>
<span class='size'>b. Nomor Pemeriksaan / Nomor uji </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_Pemeriksaan;?>
<span class='size'>c. Nama Pemilik </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nama_Pemilik;?>
<span class='size'>d. Jenis </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Jenis;?>
<span class='size'>e. Nomor Rangka </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_Rangka;?>
<span class='size'>f. Nomor Mesin </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_Mesin;?>
<span class='size'>g. Merk / Tipe / Tahun </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Merk_Tipe_tahun;?>
</div><br/>
<div class='indented2'>
II. Berdasarkan Disposisi Kepala Dinas Perhubungan Kabupaten Magetan, Nomor agenda : <?php echo $Nomor_agenda; ?> , </div>
<div class='indented'>
tanggal <?php echo $TanggalAgenda; ?>, dan sesuai dengan Surat dari <?php echo $Dari_Permintaan; ?>, Nomor : <?php echo $No_Surat_Permintaan; ?>,                 tanggal  <?php echo $TanggalSuratPermintaan; ?> Perihal : Bantuan tenaga teknis untuk Chek Phisik Kendaraan Dinas, maka dilakukan Pemeriksaan Kendaraan Bermotor sebagai berikut :</div><br/>
<div class='indented'>
<span class='size'>1.  Landasan / Frame</span><span class='colon'> :</span> <?php echo $Landasan_Frame; ?>
<span class='size'>2.  As / Gardan belakang</span><span class='colon'> :</span> <?php echo $As_Gardan_belakang; ?>
<span class='size'>3.  As / Gardan depan</span><span class='colon'> :</span> <?php echo $As_Gardan_depan; ?>
<span class='size'>4.  Pesawat rem dan peralatannya</span><span class='colon'> :</span> <?php echo $Pesawat_rem_peralatannya; ?>
<span class='size'>5.  Kemudi dan peralatannya</span><span class='colon'> :</span> <?php echo $Kemudi_peralatannya; ?>
<span class='size'>6.  Mesin</span><span class='colon'> :</span> <?php echo $Mesin; ?>
<span class='size'>7.  Cluth / Bak Versneling</span><span class='colon'> :</span> <?php echo $Cluth_Bak_Versneling; ?>
<span class='size'>8.  Alat pengatur bahan bakar</span><span class='colon'> :</span> <?php echo $Alat_pengatur_bahan_baker; ?>
<span class='size'>9.  Pendingin</span><span class='colon'> :</span> <?php echo $Pendingin; ?>
<span class='size'>10. Ban-ban</span><span class='colon'> :</span> <?php echo $Ban_ban; ?>
<span class='size'>11. Roda dan penutup roda</span><span class='colon'> :</span> <?php echo $Roda_dan_penutup_roda; ?>
<span class='size'>12. Bodi / Badan</span><span class='colon'> :</span> <?php echo $Bodi_Badan; ?>
<span class='size'>13. Spartdburd</span><span class='colon'> :</span> <?php echo $Spartdburd; ?>
<span class='size'>14. Alat Listrik</span><span class='colon'> :</span> <?php echo $Alat_Listrik; ?> 
<span class='size'>15. Alat alat pembakar</span><span class='colon'> :</span> <?php echo $Alat_alat_pembakar; ?>
<span class='size'>16. Dashboard</span><span class='colon'> :</span> <?php echo $Dashboard; ?>
<span class='size'>17. Lampu-lampu</span><span class='colon'> :</span> <?php echo $Lampu_lampu; ?>
<span class='size'>18. Penahan Shock dan peer</span><span class='colon'> :</span> <?php echo $Penahan_Shock_peer; ?>
<span class='size'>19. Kaca-kaca</span><span class='colon'> :</span> <?php echo $Kaca_kaca; ?>
<span class='size'>20. Grill mask</span><span class='colon'> :</span> <?php echo $Grill_mask; ?>
<span class='size'>21. Keadaan cat</span><span class='colon'> :</span> <?php echo $Keadaan_cat; ?>
<span class='size'>22. Atap, lantai dan tempat duduk</span><span class='colon'> :</span> <?php echo $Atap_lantai_tempat_duduk; ?> 
<span class='size'>23. Perkakas</span><span class='colon'> :</span> <?php echo $Perkakas; ?>
<span class='size'>24. Alat – alat lain yang belum ditaksir</span><span class='colon'> :</span> <?php echo $Alat_alat_lain; ?>
<br/>JUMLAH BAGIAN YANG DITAKSIR : (2) JUMLAH PROSENAN : <?php echo $totalCount1; ?><br/><br/>
a. Nilai Kondisi teknis (1)/(2) = <?php echo $totalCount1; ?>/<?php echo $totalCount; ?>  = <?php echo $average; ?> % (a)<br/>
b. Nilai penyusutan teoriti = 41% (b)<br/>
c. Nilai Teknis ditetapkan = (a)+(b) /2 = (<?php echo $average; ?>+ 41) /2  = <b><?php echo $teknistetap; ?> %</b><br/><br/><br/>
</div><br/>
<div class='indented'>

<span class='size'>Mengetahui : </span><span class='colon'>&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Magetan,&nbsp;&nbsp;<?php echo $TanggalPemeriksaan;?> <br/>
<span class='size'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kepala </span><span class='colon'>&nbsp; &nbsp;</span><br/>
<span class='size'>Seksi Keselamatan </span><span class='colon'>&nbsp;</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pemeriksa<br/><br/><br/>
<span class='size'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Sinung Wahyudi, S.Sos</u></span><span class='colon'>&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>Luckas Dwi Mahendra, ST</u><br/>
<span class='size'>NIP. 196901081993021002 </span><span class='colon'>&nbsp;</span> No.REG 035.020.PT3.01.001

<br/></div>
<br/>




</div></div>
    <textarea style="display:none;" id="resultTextarea" name="resultTextarea" rows="10" cols="50"></textarea>
<input style='width:50%;' type='hidden' name='no_pol' id='no_pol' value='<?php echo $Nomor_kendaraan;?>'>
    <!-- Script to handle the copying process -->
    <script>
        // Run the copyMyDivContent function when the page finishes loading
        document.addEventListener('DOMContentLoaded', copyMyDivContent);

        function copyMyDivContent() {
            // Get the content of the div with class 'my-div'
            const myDivContent = document.querySelector('.cetak').innerHTML;

            // Insert the content into the textarea
            const textarea = document.getElementById('resultTextarea');
            textarea.value = myDivContent;
        }
    </script>

	 
	
    


	
		   <center><button name="generate_pdf" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" type="submit">Download</button></center></form>
	</div>


  </div>
  

  
  <div class="section">










<br/><br/>

  <br/><br/>
  <a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">
    Cetak Laporan
  </a>
  <style>
    @keyframes bounce {
    }
    
    a:hover {
      background-color: #45a049;
    }
  </style>





  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    // Add animation effect to sections when scrolled into view
    function animateSections() {
      var sections = document.getElementsByClassName('section');
      var windowHeight = window.innerHeight;
      
      for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        var rect = section.getBoundingClientRect();
        
        if (rect.top <= windowHeight) {
          section.classList.add('animated');
        }
      }
    }
    
    window.addEventListener('scroll', animateSections);
    animateSections(); // Check initial state on page load
  </script>
  </div></center>
</body>
</html>


