<?php
session_start();
if (isset($_GET['keg'])) {
    // Retrieve the value of 'id'
    $keg = $_GET['keg'];
} else {
    // Handle the case when 'id' is not provided
    echo "Data Kegiatan Pengujian Yang anda cari tidak ditemukan.";
    //exit;
}
// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // If logged in, display "Welcome Username" message
    echo "<center>Penguji Aktif : <b>" . $_SESSION['username'] . " </b><a href='logout.php'>Logout</a></center>";
} else {
    // If not logged in, display "Welcome" message with a "Login" link
    echo "Silahkan <a href='login.php'>Login</a>";
	header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pemeriksaan Teknis Kendaraan</title>
<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background-color: #0D1B2A;
    color: #FFF8DC; /* Warna putih keemasan */
    padding: 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    font-weight: bold;
    font-size: 16px;
  }

  h1, h2, h3, h4, h5, h6, label, p, td, th, a {
    color: #FFF8DC !important;
    font-weight: bold;
    font-size: 16px;
  }

  h2 {
    background: linear-gradient(to right, #1E88E5, #26C6DA);
    color: #FFF8DC;
    padding: 12px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 22px;
    width: 100%;
    max-width: 600px;
    text-align: center;
  }

  .container {
    display: flex;
    justify-content: center;
    width: 100%;
  }

  .aesthetic-div {
    background: linear-gradient(to bottom right, #0D1B2A, #26C6DA);
    border-radius: 15px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
    padding: 20px;
    width: 100%;
    max-width: 800px;
    margin-bottom: 20px;
    transition: transform 0.3s ease-in-out;
    backdrop-filter: blur(10px);
  }

  .aesthetic-div:hover {
    transform: translateY(-5px);
  }

  input[type="text"], input[type="date"], select, textarea {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
    margin: 10px 0;
    background-color: #FFF8DC;
    color: #000000; /* TEKS FORM BERWARNA HITAM */
    font-weight: bold;
  }

  input:focus, select:focus, textarea:focus {
    border-color: #FFD700;
    outline: none;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }

  th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ccc;
    font-size: 16px;
    color: #FFF8DC;
  }

  th {
    background-color: #1E88E5;
  }

  tr:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }

  .btn {
    display: inline-block;
    background-color: #FFD700;
    color: #0D1B2A;
    padding: 14px 20px;
    margin-top: 10px;
    border: none;
    border-radius: 25px;
    text-decoration: none;
    font-weight: bold;
    text-align: center;
    font-size: 16px;
    transition: background-color 0.3s ease;
    cursor: pointer;
  }

  .btn:hover {
    background-color: #FFC107;
  }

  @media (max-width: 768px) {
    body {
      padding: 10px;
      font-size: 15px;
    }

    h2 {
      font-size: 18px;
    }

    input, textarea, select {
      font-size: 15px;
    }

    .btn {
      padding: 12px 16px;
      font-size: 15px;
    }

    th, td {
      font-size: 14px;
    }
  }

  .section {
    opacity: 0;
    transform: translateY(30px);
    transition: opacity 0.6s ease, transform 0.6s ease;
  }

  .section.animated {
    opacity: 1;
    transform: translateY(0);
  }
</style>
</head>
<body>
 <center> <div class="aesthetic-div">
  <div class="landing">
    <div class="overlay"></div>
    <div class="content">
      <h1>PEMERIKSAAN TEKNIS KENDARAAN</h1>
      <p>DISHUB MAGETAN</p>
	  <img src="logo.png"/><br/>
	    <a href="index.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Home</a>
		<a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Cetak</a>
		<button style="display: inline-block; padding: 10px 20px; background-color: red; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" onclick="goBack()">Kembali</button>
		    <script>
        function goBack() {
            // Navigate back to the previous page
            window.history.back();
        }
    </script>
    </div>
  </div>
 
  <div class="section">
	     <h2>Pengujian Kendaraan Bermotor</h2>

	
	 
	   <p>Isikan nilai dari setiap komponen, hasil akhir akan terkalkulasi di bagian bawah form</p>
	 
 <table> 
<tr><td>No</td><td>Tanggal</td><td>Lokasi</td><td>Penguji</td><td>No.Pol</td><td>Pemilik</td><td>Pilihan</td></tr>
<?php
// Create a connection to the MySQL database
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Construct the SELECT statement

$sql = "SELECT * FROM tabel_penilaian WHERE id_Registrasi = $keg";

// Execute the SELECT statement
$result = $conn->query($sql);

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Fetch the data as an array
    $data = $result->fetch_all(MYSQLI_ASSOC);
    
    // Loop through the array and process the data
    foreach ($data as $row) {
        // Access the column values using the column names
        $id_pemeriksaan = $row['id_pemeriksaan'];
        $Tanggal_Pemeriksaan = $row['Tanggal_Pemeriksaan'];
        $Tempat_Pemeriksaan = $row['Tempat_Pemeriksaan'];
        $Nama_Penguji_Pemeriksaan = $row['Nama_Penguji_Pemeriksaan'];
        $Nomor_kendaraan = $row['Nomor_kendaraan'];
        $Nama_Pemilik = $row['Nama_Pemilik'];
       
        // Process the data as needed
        // For example, you can echo or display the values
		
        echo "<tr><td style='background-color: #ecf5bc;'> $id_pemeriksaan</td>";
        echo "<td style='background-color: #bcf5d9;'> $Tanggal_Pemeriksaan</td>";
		echo "<td style='background-color: #f5d7bc;'> $Tempat_Pemeriksaan</td>";
		echo "<td style='background-color: #50f3a4;'> $Nama_Penguji_Pemeriksaan</td>";
		echo "<td style='background-color: #f5d7bc;'> $Nomor_kendaraan</td>";
		echo "<td style='background-color: #b2cff3;'> $Nama_Pemilik</td>";
        // ...and so on for the other columns
		echo "<td>  <a href='edit-pemeriksaan.php?id=".$id_pemeriksaan."' style='display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;'>Edit</a></td></tr>";
      
    }
} else {
    echo "Belum ada data pada daftar pemeriksaan teknis. Silahkan lakukan registrasi kegiatan pada form yang telah disediakan.";
	echo "Terjadi masalah: " . $sql . "<br>" . $conn->error;
}

// Close the database connection

?>

	</table>


	</div>



  

  
  <div class="section">










<br/><br/>

  <br/><br/>

  <style>
    @keyframes bounce {
    }
    
    a:hover {
      background-color: #45a049;
    }
  </style>





  </div>
  
  <script>
    // Add animation effect to sections when scrolled into view
    function animateSections() {
      var sections = document.getElementsByClassName('section');
      var windowHeight = window.innerHeight;
      
      for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        var rect = section.getBoundingClientRect();
        
        if (rect.top <= windowHeight) {
          section.classList.add('animated');
        }
      }
    }
    
    window.addEventListener('scroll', animateSections);
    animateSections(); // Check initial state on page load
  </script>
  </div></center>
</body>
</html>
