<?php
session_start();
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form values
	$tableName = 'tabel_penilaian';
	$id_pemeriksaan = $_POST['id_pemeriksaan'];
	$id_Registrasi = $_POST['id_Registrasi'];
    $tanggalPemeriksaan = $_POST['Tanggal_Pemeriksaan'];
    $tempatPemeriksaan = $_POST['Tempat_Pemeriksaan'];
    $namaPengujiPemeriksaan = $_POST['Nama_Penguji_Pemeriksaan'];
    $nomorKendaraan = $_POST['Nomor_kendaraan'];
    $nomorPemeriksaan = $_POST['Nomor_Pemeriksaan'];
    $namaPemilik = $_POST['Nama_Pemilik'];
    $jenis = $_POST['Jenis'];
    $nomorRangka = $_POST['Nomor_Rangka'];
    $nomorMesin = $_POST['Nomor_Mesin'];
    $merkTipeTahun = $_POST['Merk_Tipe_tahun'];
    $landasanFrame = $_POST['Landasan_Frame'];
    $asGardanBelakang = $_POST['As_Gardan_belakang'];
    $asGardanDepan = $_POST['As_Gardan_depan'];
    $pesawatRemPeralatannya = $_POST['Pesawat_rem_peralatannya'];
    $kemudiPeralatannya = $_POST['Kemudi_peralatannya'];
    $mesin = $_POST['Mesin'];
    $cluthBakVersneling = $_POST['Cluth_Bak_Versneling'];
    $alatPengaturBahanBaker = $_POST['Alat_pengatur_bahan_baker'];
    $pendingin = $_POST['Pendingin'];
    $banBan = $_POST['Ban_ban'];
    $rodaDanPenutupRoda = $_POST['Roda_dan_penutup_roda'];
    $bodiBadan = $_POST['Bodi_Badan'];
    $spartdburd = $_POST['Spartdburd'];
    $alatListrik = $_POST['Alat_Listrik'];
    $alatAlatPembakar = $_POST['Alat_alat_pembakar'];
    $dashboard = $_POST['Dashboard'];
    $lampuLampu = $_POST['Lampu_lampu'];
    $penahanShockPeer = $_POST['Penahan_Shock_peer'];
    $kacaKaca = $_POST['Kaca_kaca'];
    $grillMask = $_POST['Grill_mask'];
    $keadaanCat = $_POST['Keadaan_cat'];
    $atapLantaiTempatDuduk = $_POST['Atap_lantai_tempat_duduk'];
    $perkakas = $_POST['Perkakas'];
    $alatAlatLain = $_POST['Alat_alat_lain'];
    $totalCount1 = $_POST['totalCount1'];
	$totalCount = $_POST['totalCount'];
    $average = $_POST['average'];
    $teoriti = $_POST['teoriti'];
    $teknistetap = $_POST['teknistetap'];
	$catatan = $_POST['catatan'];

    // Database connection
    $servername = "localhost";
    $username = "nationa7_tafsir";
    $password = "nationa7_tafsir";
    $dbname = "nationa7_tafsir";
$updateSet = "
	id_Registrasi = '$id_Registrasi',
    Tanggal_Pemeriksaan = '$tanggalPemeriksaan',
    Tempat_Pemeriksaan = '$tempatPemeriksaan',
    Nama_Penguji_Pemeriksaan = '$namaPengujiPemeriksaan',
    Nomor_kendaraan = '$nomorKendaraan',
    Nomor_Pemeriksaan = '$nomorPemeriksaan',
    Nama_Pemilik = '$namaPemilik',
    Jenis = '$jenis',
    Nomor_Rangka = '$nomorRangka',
    Nomor_Mesin = '$nomorMesin',
    Merk_Tipe_tahun = '$merkTipeTahun',
    Landasan_Frame = '$landasanFrame',
    As_Gardan_belakang = '$asGardanBelakang',
    As_Gardan_depan = '$asGardanDepan',
    Pesawat_rem_peralatannya = '$pesawatRemPeralatannya',
    Kemudi_peralatannya = '$kemudiPeralatannya',
    Mesin = '$mesin',
    Cluth_Bak_Versneling = '$cluthBakVersneling',
    Alat_pengatur_bahan_baker = '$alatPengaturBahanBaker',
    Pendingin = '$pendingin',
    Ban_ban = '$banBan',
    Roda_dan_penutup_roda = '$rodaDanPenutupRoda',
    Bodi_Badan = '$bodiBadan',
    Spartdburd = '$spartdburd',
    Alat_Listrik = '$alatListrik',
    Alat_alat_pembakar = '$alatAlatPembakar',
    Dashboard = '$dashboard',
    Lampu_lampu = '$lampuLampu',
    Penahan_Shock_peer = '$penahanShockPeer',
    Kaca_kaca = '$kacaKaca',
    Grill_mask = '$grillMask',
    Keadaan_cat = '$keadaanCat',
    Atap_lantai_tempat_duduk = '$atapLantaiTempatDuduk',
    Perkakas = '$perkakas',
    Alat_alat_lain = '$alatAlatLain',
    totalCount1 = '$totalCount1',
	totalCount = '$totalCount',
    average = '$average',
    teoriti = '$teoriti',
    teknistetap = '$teknistetap',
	catatan = '$catatan'
";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
	$sql = "UPDATE $tableName SET $updateSet WHERE id_pemeriksaan = $id_pemeriksaan;";
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to insert data into the table

	




    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
		echo "<script>alert('Data Pengujian Berhasil Diperbarui'); window.history.back();</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
