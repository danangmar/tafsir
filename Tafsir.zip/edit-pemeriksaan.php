<?php
session_start();
if (isset($_GET['id'])) {
    // Retrieve the value of 'id'
    $id = $_GET['id'];
} else {
    // Handle the case when 'id' is not provided
    echo "Data Kegiatan Pengujian Yang anda cari tidak ditemukan.";
    //exit;
}
// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // If logged in, display "Welcome Username" message
    echo "<center>Penguji Aktif : <b>" . $_SESSION['username'] . " </b><a href='logout.php'>Logout</a></center>";
} else {
    // If not logged in, display "Welcome" message with a "Login" link
    echo "Silahkan <a href='login.php'>Login</a>";
	header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pemeriksaan Teknis Kendaraan</title>
 <style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background-color: #0D1B2A;
    color: #FFF8DC; /* Warna putih keemasan */
    padding: 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    font-weight: bold;
    font-size: 16px;
  }

  h1, h2, h3, h4, h5, h6, label, p, td, th, a {
    color: #FFF8DC !important;
    font-weight: bold;
    font-size: 16px;
  }

  h2 {
    background: linear-gradient(to right, #1E88E5, #26C6DA);
    color: #FFF8DC;
    padding: 12px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 22px;
    width: 100%;
    max-width: 600px;
    text-align: center;
  }

  .container {
    display: flex;
    justify-content: center;
    width: 100%;
  }

  .aesthetic-div {
    background: linear-gradient(to bottom right, #0D1B2A, #26C6DA);
    border-radius: 15px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
    padding: 20px;
    width: 100%;
    max-width: 800px;
    margin-bottom: 20px;
    transition: transform 0.3s ease-in-out;
    backdrop-filter: blur(10px);
  }

  .aesthetic-div:hover {
    transform: translateY(-5px);
  }

  input[type="text"], input[type="date"], select, textarea {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
    margin: 10px 0;
    background-color: #FFF8DC;
    color: #000000; /* TEKS FORM BERWARNA HITAM */
    font-weight: bold;
  }

  input:focus, select:focus, textarea:focus {
    border-color: #FFD700;
    outline: none;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }

  th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ccc;
    font-size: 16px;
    color: #FFF8DC;
  }

  th {
    background-color: #1E88E5;
  }

  tr:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }

  .btn {
    display: inline-block;
    background-color: #FFD700;
    color: #0D1B2A;
    padding: 14px 20px;
    margin-top: 10px;
    border: none;
    border-radius: 25px;
    text-decoration: none;
    font-weight: bold;
    text-align: center;
    font-size: 16px;
    transition: background-color 0.3s ease;
    cursor: pointer;
  }

  .btn:hover {
    background-color: #FFC107;
  }

  @media (max-width: 768px) {
    body {
      padding: 10px;
      font-size: 15px;
    }

    h2 {
      font-size: 18px;
    }

    input, textarea, select {
      font-size: 15px;
    }

    .btn {
      padding: 12px 16px;
      font-size: 15px;
    }

    th, td {
      font-size: 14px;
    }
  }

  .section {
    opacity: 0;
    transform: translateY(30px);
    transition: opacity 0.6s ease, transform 0.6s ease;
  }

  .section.animated {
    opacity: 1;
    transform: translateY(0);
  }
</style>
</head>
<body>
 <center> <div class="aesthetic-div">
  <div class="landing">
    <div class="overlay"></div>
    <div class="content">
      <h1>PEMERIKSAAN TEKNIS KENDARAAN</h1>
      <p>DISHUB MAGETAN</p>
	  <img src="logo.png"/><br/>
	    <a href="index.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Home</a>
		<a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Cetak</a>
		<button style="display: inline-block; padding: 10px 20px; background-color: red; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" onclick="goBack()">Kembali</button>
		    <script>
        function goBack() {
            // Navigate back to the previous page
            window.history.back();
        }
    </script>
    </div>
  </div>
 	<form action="edit-nilai.php" method="POST"> 
  <div class="section">
	     <h2>Pengujian Kendaraan Bermotor</h2>

	 <table>
	 
	   <p>Isikan nilai dari setiap komponen, hasil akhir akan terkalkulasi di bagian bawah form</p>
	 
	 
	 <?php
// Replace the database credentials with your actual MySQL database information
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute a MySQL query to fetch data related to the specific ID
$sql = "SELECT * FROM tabel_penilaian WHERE id_pemeriksaan = $id"; // Replace 'your_table_name' with your actual table name
$result = $conn->query($sql);

// Check if there are rows returned
if ($result->num_rows > 0) {
    // Output the data in a table format or any other format you prefer
    while ($row = $result->fetch_assoc()) {
        echo "<input style='width:30%;' type='hidden' name='id_pemeriksaan' id='id_pemeriksaan' value='" . $row['id_pemeriksaan'] . "' readonly>";
		echo "<input style='width:30%;' type='hidden' name='id_Registrasi' id='id_Registrasi' value='" . $row['id_Registrasi'] . "' readonly></td>";
		echo "<tr><td>Tanggal Pemeriksaan:</td>";
        echo "<td><input type='text' name='Tanggal_Pemeriksaan' id='Tanggal_Pemeriksaan' value='" . $row['Tanggal_Pemeriksaan'] . "' readonly></td>";
        echo "</tr>";
		echo "<tr><td>Tempat Pemeriksaan:</td>";
        echo "<td><input style='width:30%;' type='text' name='Tempat_Pemeriksaan' id='Tempat_Pemeriksaan' value='" . $row['Tempat_Pemeriksaan'] . "' readonly>";
        echo "</tr>";
		echo "<tr><td>Nama Penguji Pemeriksaan:</td>";
        echo "<td><input type='text' name='Nama_Penguji_Pemeriksaan' id='Nama_Penguji_Pemeriksaan' value='" . $row['Nama_Penguji_Pemeriksaan'] . "' readonly></td>";
		echo "</tr>";
		       echo " <tr><td><label for='Nomor_kendaraan'>Nomor Kendaraan:</label></td>";
        echo "<td><input type='text' name='Nomor_kendaraan' id='Nomor_kendaraan' value='" . $row['Nomor_kendaraan'] . "' required></td></tr>";

        echo "<tr><td><label for='Nomor_Pemeriksaan'>Nomor Pemeriksaan:</label></td>";
        echo "<td><input type='text' name='Nomor_Pemeriksaan' id='Nomor_Pemeriksaan' value='" . $row['Nomor_Pemeriksaan'] . "' required></td></tr>";

        echo "<tr><td><label for='Nama_Pemilik'>Nama Pemilik:</label></td>";
        echo "<td><input type='text' name='Nama_Pemilik' id='Nama_Pemilik' value='" . $row['Nama_Pemilik'] . "' required></td></tr>";

        echo "<tr><td><label for='Jenis'>Jenis:</label></td>";
        echo "<td><input type='text' name='Jenis' id='Jenis' value='" . $row['Jenis'] . "' required></td></tr>";

        echo "<tr><td><label for='Nomor_Rangka'>Nomor Rangka:</label></td>";
        echo "<td><input type='text' name='Nomor_Rangka' id='Nomor_Rangka' value='" . $row['Nomor_Rangka'] . "' required></td></tr>";

        echo "<tr><td><label for='Nomor_Mesin'>Nomor Mesin:</label></td>";
        echo "<td><input type='text' name='Nomor_Mesin' id='Nomor_Mesin' value='" . $row['Nomor_Mesin'] . "' required></td></tr>";

        echo "<tr><td><label for='Merk_Tipe_tahun'>Merk Tipe Tahun:</label></td>";
        echo "<td><input type='text' name='Merk_Tipe_tahun' id='Merk_Tipe_tahun' value='" . $row['Merk_Tipe_tahun'] . "' required></td></tr>";
		
        
    }


} 
// Close the database connection
$conn->close();
?>
</table>
		<hr/>
		    <!-- Table with two columns - labels and input text -->
    <table border="1" id="inputTable">
        <tr>
            <td><label for="Landasan_Frame">Landasan Frame:</label></td>
            <td><input style='width:30%;' type="text" name="Landasan_Frame" id="Landasan_Frame"></td>
        </tr>
        <tr>
            <td><label for="As_Gardan_belakang">As Gardan Belakang:</label></td>
            <td><input style='width:30%;' type="text" name="As_Gardan_belakang" id="As_Gardan_belakang"></td>
        </tr>
        <tr>
            <td><label for="As_Gardan_depan">As Gardan Depan:</label></td>
            <td><input style='width:30%;' type="text" name="As_Gardan_depan" id="As_Gardan_depan"></td>
        </tr>
        <tr>
            <td><label for="Pesawat_rem_peralatannya">Pesawat Rem Peralatannya:</label></td>
            <td><input style='width:30%;' type="text" name="Pesawat_rem_peralatannya" id="Pesawat_rem_peralatannya"></td>
        </tr>
        <tr>
            <td><label for="Kemudi_peralatannya">Kemudi Peralatannya:</label></td>
            <td><input style='width:30%;' type="text" name="Kemudi_peralatannya" id="Kemudi_peralatannya"></td>
        </tr>
        <tr>
            <td><label for="Mesin">Mesin:</label></td>
            <td><input style='width:30%;' type="text" name="Mesin" id="Mesin"></td>
        </tr>
        <tr>
            <td><label for="Cluth_Bak_Versneling">Cluth Bak Versneling:</label></td>
            <td><input style='width:30%;' type="text" name="Cluth_Bak_Versneling" id="Cluth_Bak_Versneling"></td>
        </tr>
        <tr>
            <td><label for="Alat_pengatur_bahan_baker">Alat Pengatur Bahan Baker:</label></td>
            <td><input style='width:30%;' type="text" name="Alat_pengatur_bahan_baker" id="Alat_pengatur_bahan_baker"></td>
        </tr>
        <tr>
            <td><label for="Pendingin">Pendingin:</label></td>
            <td><input style='width:30%;' type="text" name="Pendingin" id="Pendingin"></td>
        </tr>
        <tr>
            <td><label for="Ban_ban">Ban Ban:</label></td>
            <td><input style='width:30%;' type="text" name="Ban_ban" id="Ban_ban"></td>
        </tr>
        <tr>
            <td><label for="Roda_dan_penutup_roda">Roda dan Penutup Roda:</label></td>
            <td><input style='width:30%;' type="text" name="Roda_dan_penutup_roda" id="Roda_dan_penutup_roda"></td>
        </tr>
        <tr>
            <td><label for="Bodi_Badan">Bodi Badan:</label></td>
            <td><input style='width:30%;' type="text" name="Bodi_Badan" id="Bodi_Badan"></td>
        </tr>
        <tr>
            <td><label for="Spartdburd">Spartdburd:</label></td>
            <td><input style='width:30%;' type="text" name="Spartdburd" id="Spartdburd"></td>
        </tr>
        <tr>
            <td><label for="Alat_Listrik">Alat Listrik:</label></td>
            <td><input style='width:30%;' type="text" name="Alat_Listrik" id="Alat_Listrik"></td>
        </tr>
        <tr>
            <td><label for="Alat_alat_pembakar">Alat-Alat Pembakar:</label></td>
            <td><input style='width:30%;' type="text" name="Alat_alat_pembakar" id="Alat_alat_pembakar"></td>
        </tr>
        <tr>
            <td><label for="Dashboard">Dashboard:</label></td>
            <td><input style='width:30%;' type="text" name="Dashboard" id="Dashboard"></td>
        </tr>
        <tr>
            <td><label for="Lampu_lampu">Lampu Lampu:</label></td>
            <td><input style='width:30%;' type="text" name="Lampu_lampu" id="Lampu_lampu"></td>
        </tr>
        <tr>
            <td><label for="Penahan_Shock_peer">Penahan Shock Peer:</label></td>
            <td><input style='width:30%;' type="text" name="Penahan_Shock_peer" id="Penahan_Shock_peer"></td>
        </tr>
        <tr>
            <td><label for="Kaca_kaca">Kaca Kaca:</label></td>
            <td><input style='width:30%;' type="text" name="Kaca_kaca" id="Kaca_kaca"></td>
        </tr>
        <tr>
            <td><label for="Grill_mask">Grill Mask:</label></td>
            <td><input style='width:30%;' type="text" name="Grill_mask" id="Grill_mask"></td>
        </tr>
        <tr>
            <td><label for="Keadaan_cat">Keadaan Cat:</label></td>
            <td><input style='width:30%;' type="text" name="Keadaan_cat" id="Keadaan_cat"></td>
        </tr>
        <tr>
            <td><label for="Atap_lantai_tempat_duduk">Atap Lantai Tempat Duduk:</label></td>
            <td><input style='width:30%;' type="text" name="Atap_lantai_tempat_duduk" id="Atap_lantai_tempat_duduk"></td>
        </tr>
        <tr>
            <td><label for="Perkakas">Perkakas:</label></td>
            <td><input style='width:30%;' type="text" name="Perkakas" id="Perkakas"></td>
        </tr>
        <tr>
            <td><label for="Alat_alat_lain">Alat-Alat Lain:</label></td>
            <td><input style='width:30%;' type="text" name="Alat_alat_lain" id="Alat_alat_lain"></td>
        </tr>
    </table>
	    <p>Jumlah Item Di Nilai <input style='width:15%;' type="text" name="totalCount" id="totalCount" value="0" readonly></p>
		<p>JUMLAH BAGIAN YANG DITAKSIR <input style='width:15%;' type="text" name="totalCount1" id="totalCount1" value="0" readonly></p>
       <p>a. Nilai Kondisi Teknis: <input style='width:15%;' type="text" name="average" id="average" value="0" readonly>%</p>
	   <p>b. Nilai Penyusutan Teoriti: <input style='width:15%;' type="text" name="teoriti" id="teoriti" value="41" readonly>%</p>
	   <p>c. Nilai Teknis Ditetapkan: <input style='width:15%;' type="text" name="teknistetap" id="teknistetap" value="0" readonly>%</p>
	   <p>Catatan<input style='width:90%;' type="text" name="catatan" id="catatan" value=""></p>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="script.js"></script>
	<script>
$(document).ready(function() {
    // Add event listeners to input fields
    $("#inputTable input[type='text']").on("input", function() {
        updateCount();
		updateCountAndAverage();
    });
});
function updateCount() {
    // Calculate the total count of all input fields
    var totalCount1 = 0;
    $("#inputTable input[type='text']").each(function() {
        var inputValue = parseFloat($(this).val());
        if (!isNaN(inputValue)) {
            totalCount1 += inputValue;
        }
    });

    // Update the total count input value
    $("#totalCount1").val(totalCount1);
}

function updateCountAndAverage() {
    // Calculate the total count and sum of input values
    var totalCount = 0;
    var sum = 0;
    $("#inputTable input[type='text']").each(function() {
        var inputValue = parseFloat($(this).val());
        if (!isNaN(inputValue)) {
            sum += inputValue;
            totalCount++;
        }
    });

    // Update the total count and average input values
    $("#totalCount").val(totalCount);
    var average = sum / totalCount;
    $("#average").val(average.toFixed(2)); // Display average with two decimal places
	var teoritiValue = parseFloat($("#teoriti").val());
    if (!isNaN(teoritiValue)) {
        var result = (average + teoritiValue) / 2;
        $("#teknistetap").val(result.toFixed(2)); // Display result with two decimal places
    }
}

</script>
	
		   <center><button style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" type="submit">Simpan Nilai</button></center>
	</div>

  </form>
  </div>
  

  
  <div class="section">










<br/><br/>

  <br/><br/>
  <a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">
    Cetak Laporan
  </a>
  <style>
    @keyframes bounce {
    }
    
    a:hover {
      background-color: #45a049;
    }
  </style>





  </div>
  
  <script>
    // Add animation effect to sections when scrolled into view
    function animateSections() {
      var sections = document.getElementsByClassName('section');
      var windowHeight = window.innerHeight;
      
      for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        var rect = section.getBoundingClientRect();
        
        if (rect.top <= windowHeight) {
          section.classList.add('animated');
        }
      }
    }
    
    window.addEventListener('scroll', animateSections);
    animateSections(); // Check initial state on page load
  </script>
  </div></center>
</body>
</html>
