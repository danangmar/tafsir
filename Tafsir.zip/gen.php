<?php
require_once 'autoload.php';

use Dompdf\Dompdf;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$text1 = $_POST['resultTextarea'];
	$text2 = "<html><head><title></title><style>@page {margin: 0 !important;padding: 0 !important;}body { margin: 0.2cm; }</style></head><body>";
	$text3 = $_POST['no_pol'];
	$text4 = "</body></html>";

}
if (isset($_POST['generate_pdf'])) {
    // Skrip PHP untuk menghasilkan output HTML
    $output = $text2 . $text1 . $text4;

    // Inisialisasi Dompdf
	
    $dompdf = new Dompdf();
    $dompdf->set_option('enable_html5_parser', TRUE);
	$dompdf->set_option('isRemoteEnabled', TRUE);

    // (Opsional) Konfigurasi ukuran dan orientasi halaman PDF
	//$customPaperSize = array(0, 0, 210, 330);
	//$dompdf->setPaper($customPaperSize, 'portrait');
    //$dompdf->setPaper('A4', 'portrait');
	//$dompdf->setPaper('letter', 'portrait');
	$dompdf->setPaper('legal', 'portrait', [3, 3, 3, 3]);
	$dompdf->set_option('margin-top', '0');
	$dompdf->set_option('margin-right', '0');
	$dompdf->set_option('margin-bottom', '0');
	$dompdf->set_option('margin-left', '0');
    // Load output HTML ke Dompdf
    $dompdf->loadHtml($output);

    // Render HTML menjadi PDF
    $dompdf->render();
    $nama_file = $text3;
    // Simpan atau tampilkan file PDF
    $dompdf->stream("hasil_" . $nama_file . "_file.pdf");
}
echo $text1;
echo $text3;
?>
