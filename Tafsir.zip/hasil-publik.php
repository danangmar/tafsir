<?php
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

// Koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT id_pemeriksaan, Tanggal_Pemeriksaan, Tempat_Pemeriksaan, Nama_Penguji_Pemeriksaan, Nomor_kendaraan, teknistetap, catatan FROM tabel_penilaian";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pemeriksaan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background-color: #0D1B2A;
        color: #FFF8DC;
        padding: 16px;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 100vh;
        font-weight: bold;
        font-size: 16px;
      }

      h2 {
        background: linear-gradient(to right, #1E88E5, #26C6DA);
        color: #FFF8DC;
        padding: 12px 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-size: 22px;
        width: 100%;
        max-width: 600px;
        text-align: center;
      }

      .aesthetic-div {
        background: linear-gradient(to bottom right, #0D1B2A, #26C6DA);
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
        padding: 20px;
        width: 100%;
        max-width: 1000px;
        margin-bottom: 20px;
        backdrop-filter: blur(10px);
      }

      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
      }

      thead {
        background-color: #1E88E5;
      }

      th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ccc;
        font-size: 16px;
        color: #FFF8DC;
      }

      tr:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }

      /* Responsive: tampilkan data secara vertikal */
      @media (max-width: 768px) {
        table, thead, tbody, th, td, tr {
          display: block;
          width: 100%;
        }

        thead {
          display: none;
        }

        tr {
          margin-bottom: 20px;
          background-color: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
          padding: 10px;
        }

        td {
          padding: 10px;
          text-align: left;
          position: relative;
          border: none;
          border-bottom: 1px solid #ccc;
        }

        td::before {
          content: attr(data-label);
          display: block;
          font-weight: bold;
          color: #FFD700;
          margin-bottom: 5px;
        }
      }
    </style>
</head>
<body>
  <h2>Data Hasil Pemeriksaan Kendaraan</h2>
  <div class="aesthetic-div">
    <table>
      <thead>
        <tr>
          <th>ID Pemeriksaan</th>
          <th>Tanggal</th>
          <th>Tempat</th>
          <th>Nama Penguji</th>
          <th>Nomor Kendaraan</th>
          <th>Teknis Tetap</th>
          <th>Catatan</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td data-label='ID Pemeriksaan'>" . htmlspecialchars($row['id_pemeriksaan']) . "</td>";
                echo "<td data-label='Tanggal'>" . htmlspecialchars($row['Tanggal_Pemeriksaan']) . "</td>";
                echo "<td data-label='Tempat'>" . htmlspecialchars($row['Tempat_Pemeriksaan']) . "</td>";
                echo "<td data-label='Nama Penguji'>" . htmlspecialchars($row['Nama_Penguji_Pemeriksaan']) . "</td>";
                echo "<td data-label='Nomor Kendaraan'>" . htmlspecialchars($row['Nomor_kendaraan']) . "</td>";
                echo "<td data-label='Teknis Tetap'>" . htmlspecialchars($row['teknistetap']) . "</td>";
                echo "<td data-label='Catatan'>" . htmlspecialchars($row['catatan']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7' style='text-align:center;'>Tidak ada data ditemukan.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>

<?php
$conn->close();
?>
