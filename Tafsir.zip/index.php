<?php
// memulai sesi
session_start();

// memeriksa apakah user sudah melakukan login, jika sudah login alihkan ke index.php dengan fitur penuh

?>



<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Aplikasi Check Teknis Kendaraan V1.0</title>
  <style>
  body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(to bottom, #001F3F, #007BFF);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }

  .container {
    width: 95%;
    max-width: 400px;
    background-color: #F8F8F8;
    border-radius: 15px;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.3);
    padding: 20px;
    box-sizing: border-box;
  }

  h2 {
    background: linear-gradient(to right, #0D47A1, #1976D2);
    color: #FFFFFF;
    padding: 12px;
    border-radius: 10px;
    font-family: Arial, sans-serif;
    text-align: center;
    margin-bottom: 20px;
    font-size: 1.3em;
  }

  input[type="text"], input[type="date"] {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 12px;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
    font-size: 1em;
    box-sizing: border-box;
  }

  input[type="date"] {
    font-size: 1.1em;
  }

  .keypad-button {
    width: 30%;
    margin: 5px;
    padding: 15px;
    border: none;
    border-radius: 50%;
    background: radial-gradient(circle, #003399 0%, #001F3F 100%);
    color: white;
    font-size: 1.2em;
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    cursor: pointer;
    transition: transform 0.1s ease;
  }

  .keypad-button:active {
    transform: scale(0.95);
    background: radial-gradient(circle, #002266 0%, #000F33 100%);
  }

  .keypad {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    margin-top: 20px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }

  tr {
    background-color: #003399;
    color: white;
    text-align: left;
  }

  .landing {
    display: none; /* Hide background section since design is now mobile-style */
  }

  @media screen and (max-width: 480px) {
    .container {
      padding: 15px;
    }

    input[type="text"], input[type="date"] {
      font-size: 1em;
    }

    .keypad-button {
      width: 28%;
      padding: 12px;
      font-size: 1em;
    }
  }
</style>

</head>
<body>
 <center> <div class="aesthetic-div">
  <div class="landing">
    <div class="overlay"></div>
    <div class="content">
      <h1>PEMERIKSAAN TEKNIS KENDARAAN</h1>
      <p>DISHUB MAGETAN</p>
	  <img src="logo.png"/><br/>
	  	    <a href="index.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Home</a>
		<a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Cetak</a>
		<button style="display: inline-block; padding: 10px 20px; background-color: red; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" onclick="goBack()">Kembali</button>
		    <script>
        function goBack() {
            // Navigate back to the previous page
            window.history.back();
        }
    </script>
    </div>
  </div>
  
  <div class="section" style='color:white;'>
      <h2>Kegiatan Terdaftar</h2>
      <?
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // If logged in, display "Welcome Username" message
    echo "<center>Penguji Aktif : <b>" . $_SESSION['username'] . " </b><a href='logout.php'>Logout</a></center><br/>";
} else {
    // jika belum login maka tampilan index dengan link menuju ahalaman login
    include("hasil-publik.php");
    echo "Silahkan <a href='login.php'>Login</a>";
	header("Location: login.php");
    exit();
}
?>
<br/><br/>
    <tr style="padding: 10px;background-color: #003399;">
<?php
// Create a connection to the MySQL database
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Construct the SELECT statement
$sql = "SELECT id_Registrasi, Tanggal_Pemeriksaan, Tempat_Pemeriksaan, Nomor_Surat_Pemeriksaan, Tanggal_Surat_Pemeriksaan, Nama_Penguji_Pemeriksaan, Nomor_agenda, Tanggal_Agenda, No_Surat_Permintaan, Tanggal_Surat_Permintaan, Dari_Permintaan
        FROM tabel_registrasi ORDER BY Tanggal_Pemeriksaan DESC LIMIT 3";

// Execute the SELECT statement
$result = $conn->query($sql);

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Fetch the data as an array
    $data = $result->fetch_all(MYSQLI_ASSOC);
    
    // Loop through the array and process the data
    foreach ($data as $row) {
        // Access the column values using the column names
        $id_Registrasi = $row['id_Registrasi'];
        $Tanggal_Pemeriksaan = $row['Tanggal_Pemeriksaan'];
        $Tempat_Pemeriksaan = $row['Tempat_Pemeriksaan'];
        $Nomor_Surat_Pemeriksaan = $row['Nomor_Surat_Pemeriksaan'];
        $Tanggal_Surat_Pemeriksaan = $row['Tanggal_Surat_Pemeriksaan'];
        $Nama_Penguji_Pemeriksaan = $row['Nama_Penguji_Pemeriksaan'];
        $Nomor_agenda = $row['Nomor_agenda'];
        $Tanggal_Agenda = $row['Tanggal_Agenda'];
        $No_Surat_Permintaan = $row['No_Surat_Permintaan'];
        $Tanggal_Surat_Permintaan = $row['Tanggal_Surat_Permintaan'];
        $Dari_Permintaan = $row['Dari_Permintaan'];
        
        // Process the data as needed
        // For example, you can echo or display the values
        echo "<td style='padding: 10px;background-color: #003399;'> $id_Registrasi</td>";
        echo "<td style='padding: 10px;background-color: #003399;'> $Tanggal_Pemeriksaan</td>";
		echo "<td style='padding: 10px;background-color: #003399;'> $Dari_Permintaan</td>";
        // ...and so on for the other columns
		echo "<td>  <a href='pemeriksaan.php?id=".$id_Registrasi."' style='display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;'>   Lakukan Pemeriksaan</a></td>";
        echo "<br><br/><br/>";
    }
} else {
    echo "Belum ada data pada daftar pemeriksaan teknis. Silahkan lakukan registrasi kegiatan pada form yang telah disediakan.";
}

// Close the database connection

?>
    </tr><br/><br/>
    <h2>Panduan</h2>
    <p>Masukan Data Kegiatan Pemeriksaan Teknis pada Form yang telah disediakan, kemudian klik simpan untuk meregistrasi. Setelah registrasi berhasil, lakukan pemeriksaan per Unit Kendaraan melalui tombol yang tertera dibawah ini.</p>
  </div>
  
  <div class="section">
  <?php
// Assuming you have already established a database connection as shown in the previous step.

// SQL query to select all options from the "options" table
$sql = "SELECT id_penguji,Nama_Penguji FROM tabel_penguji";
  
$result = $conn->query($sql);

// Check if there are any records in the result set
if ($result->num_rows > 0) {
    // Create an empty array to store the options
    $optionsArray = array();

    // Loop through the result set and fetch data into the array
    while ($row = $result->fetch_assoc()) {
        // Append each option to the options array with the 'id' as the key and 'option_name' as the value
        $optionsArray[$row['id_penguji']] = $row['Nama_Penguji'];
    }
} else {
    // If there are no records in the database, handle the case accordingly
    echo "No options found in the database.";
}

// Close the database connection
$conn->close();
?>


    <h2>Daftarkan Kegiatan</h2>
	<form action="proccess.php" method="POST">
	<div style="line-height: 2;"><h2>Berdasarkan Disposisi Kepala Dinas Perhubungan Kabupaten Magetan, Nomor Agenda : <input type="text" placeholder="Masukan Nomor Agenda" id="Nomor_agenda" name="Nomor_agenda" required>, Tanggal Agenda <input type="date" id="Tanggal_Agenda" name="Tanggal_Agenda">, dan sesuai dengan surat dari <input type="text" placeholder="Permintaan dari Instansi" id="Dari_Permintaan" name="Dari_Permintaan">, Nomor <input type="text" placeholder="Nomor surat permintaan dari instansi." id="No_Surat_Permintaan" name="No_Surat_Permintaan">, tanggal <input type="date" id="Tanggal_Surat_Permintaan" name="Tanggal_Surat_Permintaan"> Perihal : Bantuan teknis untuk check phisik kendaraan dinas, maka dilakukan pemeriksaan kendaraan bermotor pada tanggal <input type="date" id="Tanggal_Pemeriksaan" name="Tanggal_Pemeriksaan"> berlokasi di <input type="text" placeholder="Masukan lokasi pengujian" id="Tempat_Pemeriksaan" name="Tempat_Pemeriksaan"> dengan Nomor Surat Pemeriksaan<input type="text" placeholder="Masukan nomor surat pemeriksaan" id="Nomor_Surat_Pemeriksaan" name="Nomor_Surat_Pemeriksaan">, tanggal surat Pemeriksaan <input type="date" id="Tanggal_Surat_Pemeriksaan" name="Tanggal_Surat_Pemeriksaan">, oleh Penguji : 
	
	<select id="Nama_Penguji_Pemeriksaan" name="Nama_Penguji_Pemeriksaan">
    <?php
    // Loop through the options array to generate the option elements
    foreach ($optionsArray as $id => $optionName) {
        echo "<option value='$optionName'>$id : $optionName</option>";
    }
    ?>
</select>
	
	
	
	</h2></div>
   <center><button style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" type="submit">Daftarkan</button></center>
  </form>
  </div>
  

  
  <div class="section">










<br/><br/>
  <a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">
    Lihat Daftar Kegiatan
  </a>
  <br/><br/>

  <style>
    @keyframes bounce {
    }
    
    a:hover {
      background-color: #45a049;
    }
  </style>





  </div>
  
  <script>
    // Add animation effect to sections when scrolled into view
    function animateSections() {
      var sections = document.getElementsByClassName('section');
      var windowHeight = window.innerHeight;
      
      for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        var rect = section.getBoundingClientRect();
        
        if (rect.top <= windowHeight) {
          section.classList.add('animated');
        }
      }
    }
    
    window.addEventListener('scroll', animateSections);
    animateSections(); // Check initial state on page load
  </script>
  </div></center>
</body>
</html>
