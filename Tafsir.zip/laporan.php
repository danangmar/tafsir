<?php
session_start();
if (isset($_GET['id'])) {
    // Retrieve the value of 'id'
    $id = $_GET['id'];
} if (isset($_GET['keg'])) {
    // Retrieve the value of 'id'
    $keg = $_GET['keg'];
}else {
    // Handle the case when 'id' is not provided
    echo "Data Kegiatan Pengujian Yang anda cari tidak ditemukan.";
    //exit;
}
// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // If logged in, display "Welcome Username" message
    echo "<center>Penguji Aktif : <b>" . $_SESSION['username'] . " </b><a href='logout.php'>Logout</a></center>";
} else {
    // If not logged in, display "Welcome" message with a "Login" link
    echo "Silahkan <a href='login.php'>Login</a>";
	header("Location: login.php");
    exit();
}
setlocale(LC_TIME, 'id_ID.utf8');
?>
<?php
// Replace these variables with your actual database credentials
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// First query to retrieve data from tabel_registrasi
$sql1 = "SELECT id_pemeriksaan, id_Registrasi,Nomor_kendaraan, Nomor_Pemeriksaan, Nama_Pemilik, Jenis, Nomor_Rangka, Nomor_Mesin,
                Merk_Tipe_tahun, Tanggal_Pemeriksaan, Tempat_Pemeriksaan, teknistetap, catatan
         FROM tabel_penilaian
         WHERE id_pemeriksaan = $id";

$result1 = $conn->query($sql1);

if (!$result1) {
    die("Query 1 failed: " . mysql_error());
}






// Second query to retrieve data from tabel_penilaian
$sql2 = "SELECT Nomor_Surat_Pemeriksaan, Tanggal_Surat_Pemeriksaan, Dari_Permintaan, No_Surat_Permintaan, Tanggal_Surat_Permintaan
         FROM tabel_registrasi
         WHERE id_Registrasi = $keg";
$result2 = $conn->query($sql2);

if (!$result2) {
    die("Query 2 failed: " . mysql_error());
}




// Fetch and display the results from the first query
if ($result2->num_rows > 0) {
    while ($row = $result2->fetch_assoc()) {
        $Nomor_Surat_Pemeriksaan = $row["Nomor_Surat_Pemeriksaan"];
        $Tanggal_Surat_Pemeriksaan = $row["Tanggal_Surat_Pemeriksaan"];
		$timestamp1 = strtotime($Tanggal_Surat_Pemeriksaan);
		$TanggalSuratPemeriksaan = strftime('%e %B %Y', $timestamp1);
        $Dari_Permintaan = $row["Dari_Permintaan"];
        $No_Surat_Permintaan = $row["No_Surat_Permintaan"];
        $Tanggal_Surat_Permintaan = $row["Tanggal_Surat_Permintaan"];
		$timestamp2 = strtotime($Tanggal_Surat_Permintaan);
		$TanggalSuratPermintaan = strftime('%e %B %Y', $timestamp2);
    }
} else {
    echo "No records found for the first query.";
}

echo "<br>"; // Add a line break for separation of results

// Fetch and display the results from the second query
if ($result1->num_rows > 0) {
    while ($row = $result1->fetch_assoc()) {
        $Nomor_kendaraan = $row["Nomor_kendaraan"];
        $Nomor_Pemeriksaan = $row["Nomor_Pemeriksaan"];
        $Nama_Pemilik = $row["Nama_Pemilik"];
        $Jenis = $row["Jenis"];
        $Nomor_Rangka = $row["Nomor_Rangka"];
        $Nomor_Mesin = $row["Nomor_Mesin"];
        $Merk_Tipe_tahun = $row["Merk_Tipe_tahun"];
        $Tanggal_Pemeriksaan = $row["Tanggal_Pemeriksaan"];
		$timestamp3 = strtotime($Tanggal_Pemeriksaan);
		$TanggalPemeriksaan = strftime('%e %B %Y', $timestamp2);
        $Tempat_Pemeriksaan = $row["Tempat_Pemeriksaan"];
        $teknistetap = $row["teknistetap"];
		$catatan = $row["catatan"];
    }
} else {
    echo "No records found for the second query.";
}

// Close the MySQL connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Pemeriksaan Teknis Kendaraan</title>
  <style>
    .aesthetic-div {
      width: 80%;
      height: auto;
      background-color: #F8F8F8;
      border: 1px solid #E6E6E6;
      border-radius: 10px;
      box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);
      font-family: Arial, sans-serif;
      
      color: #333333;
      text-align: left;
    }
	.container {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    body {
      margin: 12;
      padding: 12;
      font-family: Arial, sans-serif;
	        justify-content: center;
      align-items: center;
    }
    
    .landing {
      position: relative;
      height: auto;
	  opacity: 100;
      background-image: url('index_files/abstract-template-blue-background-white-squares-free-vector.jpg');
      background-size: cover;
      background-position: center;
    }
    
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 255, 0.7);
    }
    
    .content {
      position: relative;
      z-index: 1;
      text-align: center;
      color: #fff;
    }
    
    .section {
      opacity: 5;
      transform: translateY(50px);
      transition: opacity 0.5s ease, transform 0.5s ease;
    }
    
    .section.animated {
      opacity: 1;
      transform: translateY(0);
    }
	    h2 {
      background: linear-gradient(to right, #3F51B5, #2196F3);
      color: #FFFFFF;
      padding: 10px;
      border-radius: 5px;
      font-family: Arial, sans-serif;
      text-align: center;
    }
	    input[type="text"] {
      width: 80%;
	  height: 30px;
    }
	    table {
     
	   width: 100%;
    }
	    tr {
		font-size: 25px;
 
    }

  </style>
</head>
<body>
 <center> <div class="aesthetic-div">
  <div class="landing">
    <div class="overlay"></div>
    <div class="content">
      <h1>PEMERIKSAAN TEKNIS KENDARAAN</h1>
      <p>DISHUB MAGETAN</p>
	  <img src="logo.png"/><br/>
	    <a href="index.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Home</a>
		<a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: blue; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">Cetak</a>
		    <button style="display: inline-block; padding: 10px 20px; background-color: red; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" onclick="goBack()">Kembali</button>

    <script>
        function goBack() {
            // Navigate back to the previous page
            window.history.back();
        }
    </script>
    </div>
  </div>

  <div class="section"><form action="gen.php" method="post">
	     <h2>Pengujian Kendaraan Bermotor</h2>


<div class="cetak">
<style>.size {display: inline-block;width: 50%;}.colon {display: inline-block;width: 20px;text-align: center;}.my-div {width: 21cm;height: 27.5cm;background-color: white;border: 0px solid black;line-height: 1.5;}@media (min-width: 768px) {.my-div {width: 21cm;height: 33.2cm;}}.indented {margin-left: 1.5cm;margin-right: 1.5cm;}.indenta {margin-left: 0.5cm;margin-right: 2cm;}.ttdkadin {margin-left: 10cm;margin-right: 1.5cm;}</style>	<div class='my-div'><center><img width='auto' height='auto' src='https://danangmardyanto.kir.my.id/header.png'/><br/><u><b>LAPORAN PEMERIKSAAN TEKNIS KENDARAAN</b></u><br/>Nomor : <?php echo $Nomor_Surat_Pemeriksaan; ?></center><p class='indented'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Berdasarkan surat dari <?php echo $Dari_Permintaan;?> No: <?php echo $No_Surat_Permintaan;?>, <?php echo $TanggalSuratPermintaan;?>, Perihal : Bantuan tenaga teknis untuk chek phisik kendaraan dinas, bahwa kendaraan :</p>

<div class='indented'>
<span class='size'>a. Nomor Kendaraan</span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_kendaraan;?>
<span class='size'>b. Nomor Pemeriksaan / Nomor uji </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_Pemeriksaan;?>
<span class='size'>c. Nama Pemilik </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nama_Pemilik;?>
<span class='size'>d. Jenis </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Jenis;?>
<span class='size'>e. Nomor Rangka </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_Rangka;?>
<span class='size'>f. Nomor Mesin </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Nomor_Mesin;?>
<span class='size'>g. Merk / Tipe / Tahun </span><span class='colon'>:</span>&nbsp;&nbsp;<?php echo $Merk_Tipe_tahun;?>
</div>

<p class='indented'><span class='size'>Setelah diadakan pemeriksaan pada:</span> <br/>
<span class='size'>Tanggal	</span><span class='colon'>:</span> <?php echo $TanggalPemeriksaan;?><br/>
<span class='size'>Tempat	</span><span class='colon'>:</span> <?php echo $Tempat_Pemeriksaan;?><br/>
<span class='size'>Ditetapkan Nilai Teknis sebesar </span><span class='colon'>:</span>   <?php echo $teknistetap;?><br/>
Ditetapkan hasil pemeriksaan kendaraan bermotor sebagai kelengkapan pelelangan persyaratan proses penghapusan.</p><br/>



<div class='ttdkadin'><center>Magetan,&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $TanggalSuratPemeriksaan;?> <br/>KEPALA DINAS PERHUBUNGAN<br/>KABUPATEN MAGETAN<br/><br/><br/><u>Drs. WELLY KRISTANTO,MSi.</u><br/>Pembina Utama Muda<br/>NIP. 19690508 198903 1 003</center><br/></div>
<br/>
<div class='indented'>1. Catatan : <?php echo $catatan;?></div>



</div></div>
    <textarea style="display:none;" id="resultTextarea" name="resultTextarea" rows="10" cols="50"></textarea>
<input style='width:50%;' type='hidden' name='no_pol' id='no_pol' value='<?php echo $Nomor_kendaraan;?>'>
    <!-- Script to handle the copying process -->
    <script>
        // Run the copyMyDivContent function when the page finishes loading
        document.addEventListener('DOMContentLoaded', copyMyDivContent);

        function copyMyDivContent() {
            // Get the content of the div with class 'my-div'
            const myDivContent = document.querySelector('.cetak').innerHTML;

            // Insert the content into the textarea
            const textarea = document.getElementById('resultTextarea');
            textarea.value = myDivContent;
        }
    </script>

	 
	
    


	
		   <center><button name="generate_pdf" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;" type="submit">Download</button></center></form>
	</div>


  </div>
  

  
  <div class="section">










<br/><br/>

  <br/><br/>
  <a href="daftar-keg.php" style="display: inline-block; padding: 10px 20px; background-color: #4CAF50; color: #fff; text-decoration: none; font-weight: bold; border-radius: 4px; animation: bounce 1s infinite;">
    Cetak Laporan
  </a>
  <style>
    @keyframes bounce {
    }
    
    a:hover {
      background-color: #45a049;
    }
  </style>





  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    // Add animation effect to sections when scrolled into view
    function animateSections() {
      var sections = document.getElementsByClassName('section');
      var windowHeight = window.innerHeight;
      
      for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        var rect = section.getBoundingClientRect();
        
        if (rect.top <= windowHeight) {
          section.classList.add('animated');
        }
      }
    }
    
    window.addEventListener('scroll', animateSections);
    animateSections(); // Check initial state on page load
  </script>
  </div></center>
</body>
</html>


