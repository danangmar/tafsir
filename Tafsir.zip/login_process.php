<?php
// Start a new or resume an existing session
session_start();

// Replace with your actual database credentials
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

// Establish a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the password from the form input
$inputPassword = $_POST['password'];

// Query the database to get the password
$sql = "SELECT Nama_Penguji, password FROM tabel_penguji LIMIT 1";
$result = $conn->query($sql);

// Check if the query returned any results
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $storedPassword = $row['password'];
    // Verify the password (plain text comparison for demonstration purposes only)
    if ($inputPassword === $storedPassword) {
        // Set session variables to indicate successful login
        $_SESSION['loggedin'] = true;
		$_SESSION['username'] = $row['Nama_Penguji'];
        // Redirect to index.php
        header("Location: index.php");
        exit();
    }
}

// If login fails, redirect back to login.php
header("Location: login.php");
exit();
?>
