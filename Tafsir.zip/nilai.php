<?php
session_start();
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form values
	$id_Registrasi = $_POST['id_Registrasi'];
    $tanggalPemeriksaan = $_POST['Tanggal_Pemeriksaan'];
    $tempatPemeriksaan = $_POST['Tempat_Pemeriksaan'];
    $namaPengujiPemeriksaan = $_POST['Nama_Penguji_Pemeriksaan'];
    $nomorKendaraan = $_POST['Nomor_kendaraan'];
    $nomorPemeriksaan = $_POST['Nomor_Pemeriksaan'];
    $namaPemilik = $_POST['Nama_Pemilik'];
    $jenis = $_POST['Jenis'];
    $nomorRangka = $_POST['Nomor_Rangka'];
    $nomorMesin = $_POST['Nomor_Mesin'];
    $merkTipeTahun = $_POST['Merk_Tipe_tahun'];
    $landasanFrame = $_POST['Landasan_Frame'];
    $asGardanBelakang = $_POST['As_Gardan_belakang'];
    $asGardanDepan = $_POST['As_Gardan_depan'];
    $pesawatRemPeralatannya = $_POST['Pesawat_rem_peralatannya'];
    $kemudiPeralatannya = $_POST['Kemudi_peralatannya'];
    $mesin = $_POST['Mesin'];
    $cluthBakVersneling = $_POST['Cluth_Bak_Versneling'];
    $alatPengaturBahanBaker = $_POST['Alat_pengatur_bahan_baker'];
    $pendingin = $_POST['Pendingin'];
    $banBan = $_POST['Ban_ban'];
    $rodaDanPenutupRoda = $_POST['Roda_dan_penutup_roda'];
    $bodiBadan = $_POST['Bodi_Badan'];
    $spartdburd = $_POST['Spartdburd'];
    $alatListrik = $_POST['Alat_Listrik'];
    $alatAlatPembakar = $_POST['Alat_alat_pembakar'];
    $dashboard = $_POST['Dashboard'];
    $lampuLampu = $_POST['Lampu_lampu'];
    $penahanShockPeer = $_POST['Penahan_Shock_peer'];
    $kacaKaca = $_POST['Kaca_kaca'];
    $grillMask = $_POST['Grill_mask'];
    $keadaanCat = $_POST['Keadaan_cat'];
    $atapLantaiTempatDuduk = $_POST['Atap_lantai_tempat_duduk'];
    $perkakas = $_POST['Perkakas'];
    $alatAlatLain = $_POST['Alat_alat_lain'];
    $totalCount1 = $_POST['totalCount1'];
	$totalCount = $_POST['totalCount'];
    $average = $_POST['average'];
    $teoriti = $_POST['teoriti'];
    $teknistetap = $_POST['teknistetap'];
	$catatan = $_POST['catatan'];

    // Database connection
    $servername = "localhost";
    $username = "nationa7_tafsir";
    $password = "nationa7_tafsir";
    $dbname = "nationa7_tafsir";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to insert data into the table
    $sql = "INSERT IGNORE INTO tabel_penilaian (
        id_Registrasi,Tanggal_Pemeriksaan, Tempat_Pemeriksaan, Nama_Penguji_Pemeriksaan, Nomor_kendaraan, Nomor_Pemeriksaan, Nama_Pemilik, Jenis, Nomor_Rangka, Nomor_Mesin, Merk_Tipe_tahun, Landasan_Frame, As_Gardan_belakang, As_Gardan_depan, Pesawat_rem_peralatannya, Kemudi_peralatannya, Mesin, Cluth_Bak_Versneling, Alat_pengatur_bahan_baker, Pendingin, Ban_ban, Roda_dan_penutup_roda, Bodi_Badan, Spartdburd, Alat_Listrik, Alat_alat_pembakar, Dashboard, Lampu_lampu, Penahan_Shock_peer, Kaca_kaca, Grill_mask, Keadaan_cat, Atap_lantai_tempat_duduk, Perkakas, Alat_alat_lain, totalCount1,totalCount, average, teoriti, teknistetap, catatan
    ) VALUES (
        '$id_Registrasi','$tanggalPemeriksaan', '$tempatPemeriksaan', '$namaPengujiPemeriksaan', '$nomorKendaraan', '$nomorPemeriksaan', '$namaPemilik', '$jenis', '$nomorRangka', '$nomorMesin', '$merkTipeTahun', '$landasanFrame', '$asGardanBelakang', '$asGardanDepan', '$pesawatRemPeralatannya', '$kemudiPeralatannya', '$mesin', '$cluthBakVersneling', '$alatPengaturBahanBaker', '$pendingin', '$banBan', '$rodaDanPenutupRoda', '$bodiBadan', '$spartdburd', '$alatListrik', '$alatAlatPembakar', '$dashboard', '$lampuLampu', '$penahanShockPeer', '$kacaKaca', '$grillMask', '$keadaanCat', '$atapLantaiTempatDuduk', '$perkakas', '$alatAlatLain', '$totalCount1', '$totalCount','$average', '$teoriti', '$teknistetap', '$catatan'
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
		echo "<script>alert('Data Pengujian Berhasil Diinput!'); window.history.back();</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
