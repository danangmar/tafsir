<?php
session_start();

// Store the form data in session variables

$_SESSION['Tanggal_Pemeriksaan'] = $_POST['Tanggal_Pemeriksaan'];
$_SESSION['Tempat_Pemeriksaan'] = $_POST['Tempat_Pemeriksaan'];
$_SESSION['Nomor_Surat_Pemeriksaan'] = $_POST['Nomor_Surat_Pemeriksaan'];
$_SESSION['Tanggal_Surat_Pemeriksaan'] = $_POST['Tanggal_Surat_Pemeriksaan'];
$_SESSION['Nama_Penguji_Pemeriksaan'] = $_POST['Nama_Penguji_Pemeriksaan'];
$_SESSION['Nomor_agenda'] = $_POST['Nomor_agenda'];
$_SESSION['Tanggal_Agenda'] = $_POST['Tanggal_Agenda'];
$_SESSION['No_Surat_Permintaan'] = $_POST['No_Surat_Permintaan'];
$_SESSION['Tanggal_Surat_Permintaan'] = $_POST['Tanggal_Surat_Permintaan'];
$_SESSION['Dari_Permintaan'] = $_POST['Dari_Permintaan'];

// Create a connection to the MySQL database
$servername = "localhost";
$username = "nationa7_tafsir";
$password = "nationa7_tafsir";
$dbname = "nationa7_tafsir";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Construct the INSERT INTO statement using session values
$sql = "INSERT INTO tabel_registrasi (Tanggal_Pemeriksaan, Tempat_Pemeriksaan, Nomor_Surat_Pemeriksaan, Tanggal_Surat_Pemeriksaan, Nama_Penguji_Pemeriksaan, Nomor_agenda, Tanggal_Agenda, No_Surat_Permintaan, Tanggal_Surat_Permintaan, Dari_Permintaan) 
        VALUES ('{$_SESSION['Tanggal_Pemeriksaan']}', '{$_SESSION['Tempat_Pemeriksaan']}', '{$_SESSION['Nomor_Surat_Pemeriksaan']}', '{$_SESSION['Tanggal_Surat_Pemeriksaan']}', '{$_SESSION['Nama_Penguji_Pemeriksaan']}', '{$_SESSION['Nomor_agenda']}', '{$_SESSION['Tanggal_Agenda']}', '{$_SESSION['No_Surat_Permintaan']}', '{$_SESSION['Tanggal_Surat_Permintaan']}', '{$_SESSION['Dari_Permintaan']}')";

// Execute the INSERT INTO statement
if ($conn->query($sql) === TRUE) {
    // Success message and redirect
    echo "<script>alert('Data Kegiatan Berhasil Didaftarkan'); window.location.href = 'index.php';</script>";
} else {
    // Error message and MySQL/PHP error report
    echo "Terjadi masalah: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
