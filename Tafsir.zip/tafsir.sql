-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2023 at 05:53 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tafsir`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_penguji`
--

CREATE TABLE `tabel_penguji` (
  `id_penguji` int(20) NOT NULL,
  `Nama_Penguji` varchar(225) NOT NULL,
  `no_reg_Penguji` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_penguji`
--

INSERT INTO `tabel_penguji` (`id_penguji`, `Nama_Penguji`, `no_reg_Penguji`, `password`) VALUES
(1, 'Luckas Dwi Mahendra, ST', 'No.REG 035.020.PT3.01.001', 'mahendra');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_penilaian`
--

CREATE TABLE `tabel_penilaian` (
  `id_pemeriksaan` int(225) NOT NULL,
  `id_Registrasi` int(20) NOT NULL,
  `Tanggal_Pemeriksaan` date NOT NULL,
  `Tempat_Pemeriksaan` varchar(225) NOT NULL,
  `Nama_Penguji_Pemeriksaan` varchar(225) NOT NULL,
  `Nomor_kendaraan` varchar(225) NOT NULL,
  `Nomor_Pemeriksaan` varchar(225) NOT NULL,
  `Nama_Pemilik` varchar(225) NOT NULL,
  `Jenis` varchar(225) NOT NULL,
  `Nomor_Rangka` varchar(225) NOT NULL,
  `Nomor_Mesin` varchar(225) NOT NULL,
  `Merk_Tipe_tahun` varchar(225) NOT NULL,
  `Landasan_Frame` varchar(225) NOT NULL,
  `As_Gardan_belakang` varchar(225) NOT NULL,
  `As_Gardan_depan` varchar(225) NOT NULL,
  `Pesawat_rem_peralatannya` varchar(225) NOT NULL,
  `Kemudi_peralatannya` varchar(225) NOT NULL,
  `Mesin` varchar(225) NOT NULL,
  `Cluth_Bak_Versneling` varchar(225) NOT NULL,
  `Alat_pengatur_bahan_baker` varchar(225) NOT NULL,
  `Pendingin` varchar(225) NOT NULL,
  `Ban_ban` varchar(225) NOT NULL,
  `Roda_dan_penutup_roda` varchar(225) NOT NULL,
  `Bodi_Badan` varchar(225) NOT NULL,
  `Spartdburd` varchar(225) NOT NULL,
  `Alat_Listrik` varchar(225) NOT NULL,
  `Alat_alat_pembakar` varchar(225) NOT NULL,
  `Dashboard` varchar(225) NOT NULL,
  `Lampu_lampu` varchar(225) NOT NULL,
  `Penahan_Shock_peer` varchar(225) NOT NULL,
  `Kaca_kaca` varchar(225) NOT NULL,
  `Grill_mask` varchar(225) NOT NULL,
  `Keadaan_cat` varchar(225) NOT NULL,
  `Atap_lantai_tempat_duduk` varchar(225) NOT NULL,
  `Perkakas` varchar(225) NOT NULL,
  `Alat_alat_lain` varchar(225) NOT NULL,
  `totalCount1` varchar(225) NOT NULL,
  `totalCount` int(225) NOT NULL,
  `average` varchar(225) NOT NULL,
  `teoriti` varchar(225) NOT NULL,
  `teknistetap` varchar(225) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_penilaian`
--

INSERT INTO `tabel_penilaian` (`id_pemeriksaan`, `id_Registrasi`, `Tanggal_Pemeriksaan`, `Tempat_Pemeriksaan`, `Nama_Penguji_Pemeriksaan`, `Nomor_kendaraan`, `Nomor_Pemeriksaan`, `Nama_Pemilik`, `Jenis`, `Nomor_Rangka`, `Nomor_Mesin`, `Merk_Tipe_tahun`, `Landasan_Frame`, `As_Gardan_belakang`, `As_Gardan_depan`, `Pesawat_rem_peralatannya`, `Kemudi_peralatannya`, `Mesin`, `Cluth_Bak_Versneling`, `Alat_pengatur_bahan_baker`, `Pendingin`, `Ban_ban`, `Roda_dan_penutup_roda`, `Bodi_Badan`, `Spartdburd`, `Alat_Listrik`, `Alat_alat_pembakar`, `Dashboard`, `Lampu_lampu`, `Penahan_Shock_peer`, `Kaca_kaca`, `Grill_mask`, `Keadaan_cat`, `Atap_lantai_tempat_duduk`, `Perkakas`, `Alat_alat_lain`, `totalCount1`, `totalCount`, `average`, `teoriti`, `teknistetap`, `catatan`) VALUES
(13, 13, '2023-07-24', 'Halaman Polres Magetan', 'Luckas Dwi Mahendra, ST', 'AE 7687 KK', '-', 'Charisma Ganteng', 'Truk Bak Terbuka', '7878788-Nomor Rangka', '000090-Nomor Mesin', 'Elf / 2023', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '1584', 24, '66.00', '41', '53.50', ''),
(15, 13, '2023-07-24', 'Halaman Polres Magetan', 'Luckas Dwi Mahendra, ST', 'AE 7600 KK', '-', 'Chacha Kawaii', 'Truk Bak Tertutup', '0008788-Nomor Rangka', '999090-Nomor Mesin', 'Mitsubishi / 2023', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '120', 24, '5.00', '41', '23.00', ''),
(16, 14, '2023-07-26', 'Halaman Kejaksaan Negeri Magetan', 'Luckas Dwi Mahendra, ST', 'ae 1111 np', '-', 'Charisma Ganteng Banget', 'Truk Bak Terbuka', '7878788-Nomor Rangka2', '000090-Nomor Mesin2', 'Elf / 2023 / 2', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '99', '2376', 24, '99.00', '41', '70.00', 'Test Catatan'),
(17, 14, '2023-07-26', 'Halaman Kejaksaan Negeri Magetan', 'Luckas Dwi Mahendra, ST', 'ae 1122 np', '-', 'Chacha Kawaii', 'Truk Bak Tertutup', '7878788-Nomor Rangka2', '999090-Nomor Mesin2', 'Mitsubishi / 2023 2', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '72', 24, '3.00', '41', '22.00', ''),
(21, 14, '2023-07-26', 'Halaman Kejaksaan Negeri Magetan', 'Luckas Dwi Mahendra, ST', 'AE 7777 NN', 'NOMOR PEMERIKSAAN', 'CHACHA KAWAIII', 'PICK UP', 'NOMOR RANGKA', 'NOMOR MESIN', 'CARRY 2001', '67', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '66', '1585', 24, '66.04', '41', '53.52', 'KONDISI ISTIMEWA'),
(22, 13, '2023-07-24', 'Halaman Polres Magetan', 'Luckas Dwi Mahendra, ST', 'AE 0707 NN', 'NOMOR PEMERIKSAAN 0707', 'ADEK CHACHA KAWAII', 'PICK UP', 'NOMOR RANGKA 0707', 'NOMOR MESIN 0707', 'CARRY 0707 / 2021', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '70', '1680', 24, '70.00', '41', '55.50', 'Surat-surat Lengkap Tidak ada Pelanggaran');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_registrasi`
--

CREATE TABLE `tabel_registrasi` (
  `id_Registrasi` int(20) NOT NULL,
  `Tanggal_Pemeriksaan` date NOT NULL,
  `Tempat_Pemeriksaan` varchar(225) NOT NULL,
  `Nomor_Surat_Pemeriksaan` varchar(225) NOT NULL,
  `Tanggal_Surat_Pemeriksaan` date NOT NULL,
  `Nama_Penguji_Pemeriksaan` text NOT NULL,
  `Nomor_agenda` varchar(225) NOT NULL,
  `Tanggal_Agenda` date NOT NULL,
  `No_Surat_Permintaan` varchar(225) NOT NULL,
  `Tanggal_Surat_Permintaan` date NOT NULL,
  `Dari_Permintaan` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_registrasi`
--

INSERT INTO `tabel_registrasi` (`id_Registrasi`, `Tanggal_Pemeriksaan`, `Tempat_Pemeriksaan`, `Nomor_Surat_Pemeriksaan`, `Tanggal_Surat_Pemeriksaan`, `Nama_Penguji_Pemeriksaan`, `Nomor_agenda`, `Tanggal_Agenda`, `No_Surat_Permintaan`, `Tanggal_Surat_Permintaan`, `Dari_Permintaan`) VALUES
(13, '2023-07-24', 'Halaman Polres Magetan', '7890654321PEMERIKSAAN', '2023-07-24', 'Luckas Dwi Mahendra, ST', '001', '2023-07-24', '1234567890PERMINTAAN', '2023-07-19', 'Kepolisian Resort Magetan'),
(14, '2023-07-26', 'Halaman Kejaksaan Negeri Magetan', '7890654321PEMERIKSAAN2', '2023-07-25', 'Luckas Dwi Mahendra, ST', '002', '2023-07-25', '1234567890PERMINTAAN2', '2023-07-25', 'Kejaksaan Negeri Magetan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_penguji`
--
ALTER TABLE `tabel_penguji`
  ADD PRIMARY KEY (`id_penguji`);

--
-- Indexes for table `tabel_penilaian`
--
ALTER TABLE `tabel_penilaian`
  ADD PRIMARY KEY (`id_pemeriksaan`),
  ADD UNIQUE KEY `Nomor_kendaraan` (`Nomor_kendaraan`);

--
-- Indexes for table `tabel_registrasi`
--
ALTER TABLE `tabel_registrasi`
  ADD PRIMARY KEY (`id_Registrasi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_penguji`
--
ALTER TABLE `tabel_penguji`
  MODIFY `id_penguji` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tabel_penilaian`
--
ALTER TABLE `tabel_penilaian`
  MODIFY `id_pemeriksaan` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tabel_registrasi`
--
ALTER TABLE `tabel_registrasi`
  MODIFY `id_Registrasi` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
